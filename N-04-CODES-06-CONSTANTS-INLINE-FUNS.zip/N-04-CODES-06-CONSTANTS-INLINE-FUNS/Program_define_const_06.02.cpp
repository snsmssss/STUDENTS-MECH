//  Program_define_const_06.02.cpp
#include <iostream>
#include <cmath>
using namespace std;
#define TWO 2
#define PI 4.0*atan(1.0);

int main() { int r= 10;
    // No replacement by CPP
    double peri = TWO * PI * r;
    cout << "Perimeter = " << peri << endl;
    }
    /*Perimeter = 62.8319*/