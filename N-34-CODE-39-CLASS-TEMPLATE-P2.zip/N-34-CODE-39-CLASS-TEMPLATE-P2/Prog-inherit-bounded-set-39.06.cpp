


//Templates and Inheritance Example: Bounded Set Application

#include <iostream>
using namespace std;
#include "BoundSet.h"

int main() {
    BoundSet<int> bsi(3, 21); // Allow values between 3 and 21
    Set<int> *setptr = &bsi;

    for (int i = 0; i < 25; i++)
        setptr->add(i); // Set<T>::add(const T&) is virtual

    if (bsi.find(4)) // Within bound
        cout << "We found an expected value\n";

    if (!bsi.find(0)) // Outside lower bound
        cout << "We found NO unexpected value\n";

    if (!bsi.find(25)) // Outside upper bound
        cout << "We found NO unexpected value\n";
}

//We found an expected value
//We found NO unexpected value
//We found NO unexpected value

// Uses BoundSet to maintain and search elements

