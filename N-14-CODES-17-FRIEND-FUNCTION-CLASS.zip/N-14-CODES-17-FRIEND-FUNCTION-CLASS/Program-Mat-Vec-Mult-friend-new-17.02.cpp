#include <iostream>
using namespace std;
class Matrix; // Forward declaration
class Vect { int e_[3]; int n_; public:
    Vect(int n): n_(n) { 
       for (int i=0; i < n_; ++i) // Arbitrary 
           e_[i]=i+1; // init.
}
 void Clear() { // Set a zero vector 
   for(int i = 0;i < n_; ++i)
        e_[i] = 0;
}
void Show() { // Show the vector
    for(int i = 0 ; i < n_; ++i)   
        cout << e_[i] << " "; 
    cout << endl << endl; 
}
friend Vect Prod(Matrix *pM, Vect *pV);
};
class Matrix { int e_[3][3]; int m_, n_; public:
    Matrix(int m, int n): m_(m), n_(n) { // Arbitrar
        for (int i=0; i < m_; ++i) // init.
            for(int j = 0; j < n_; ++j) e_[i][j] = i + j;
    }
     void Show() { // Show the matrix  
          for (int i = 0; i < m_; ++i) {  
              for (int j = 0; j < n_; ++j)  
                  cout << e_[i][j] << " ";
              cout << endl; 
          } cout << endl;
    } friend Vect Prod(Matrix *pM, Vect *pV);
 };
Vect Prod(Matrix *pM, Vect *pV) {  
     Vect v(pM->m_); v.Clear();
     for(int i = 0; i < pM->m_; ++i) 
         for(int j = 0; j < pM->n_; ++j)  
            v.e_[i] += pM->e_[i][j] * pV->e_[j];
     return v;
}
int main() {
  Matrix M(2, 3);
  Vect V(3);
  Vect PV = Prod(&M, &V);
  M.Show();
  V.Show();
  PV.Show();
  return 0;
}
/*0 1 2 
1 2 3 

1 2 3 

8 14 
*/