#include <iostream>
#include <cstring>
#include <cstdlib>
using namespace std;
struct String { char *str_;  //container
                size_t len_; //length
};
void print(const String& s) {
    cout << s.str_ << ": "
         << s.len_ << endl;
}
int main() { String s;

    // Init data members
    s.str_ = strdup("Partha");
    s.len_ = strlen(s.str_);
    print(s);
    free(s.str_);
}
/*Partha: 6*/
