//friend function 
#include<iostream>
using namespace std;
class MyClass { int data_;
public:
     MyClass(int i) data_(i){}
     friend void display (const MyClass& a);
};
void display (const MyClass& a) 
{ // global function cout << "data = " << a.data_; // okay
}
int main() {
    MyClass obj (10);
    display(obj);
}
