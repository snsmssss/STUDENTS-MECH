#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
using namespace std;

template <typename T>
string ToString(const T& value)
{
    stringstream ss;
    ss << value;
    return ss.str();
}
class Logger
{
public:
    Logger(string file)
    {
        m_output.open(file);
    }

    void operator()(string data)
    {
        cout << data << endl;
        m_output << data << endl;
    }

private:
    ofstream m_output;
};

