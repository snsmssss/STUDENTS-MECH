#include <iostream>
using namespace std;
//In C and C++, the typedef keyword is used to define
// an alias for a type. The line:
typedef void (*FunPtr) (int, int);
//creates a new type alias FunPtr for a function pointer type
//that points to functions returning void and taking 
// two int arguments.
void Add(int i, int j)
{
    cout << i << " + " << j << " = " << i + j << endl;
}

void Subtract(int i, int j)
{
    cout << i <<" - " << j << " = " << i - j << endl;
}

int main()
{
    FunPtr pa, ps;
    pa = & Add;
    pa(6 , 4);
    ps = & Subtract;
    ps(6 , 4);
    return 0;
}