#include <iostream>
#include <fstream>
using namespace std;
int main () {ofstream myfile;//output
    myfile.open("example.txt");//Open file
    myfile << "Writing this to a file.\n";//stream to output
    myfile.close();//Close:flush stream to file

}