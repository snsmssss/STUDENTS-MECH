#include <iostream>
using namespace std;
//dynamic_cast be used only for class ptr and ref
//dynamic_cast<new-data type> (expression)
class Base {
};
class Derived : public Base{
}
int main(){
    Base b;
    Derived d;
// Up cast
    Base *bptr=dynamic_cast<Base*>(&d);
// Down cast    
    Base *dptr=dynamic_cast<Derived*>(&b);
//error: cannot 'dynamic_cast' '& b' (of type 'class Base*') to type 'class Derived*' (source type is not polymorphic)
//15 | Base *dptr=dynamic_cast<Derived*>(&b);
}