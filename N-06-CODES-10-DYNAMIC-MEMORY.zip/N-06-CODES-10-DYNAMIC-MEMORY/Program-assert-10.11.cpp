//Program-assert-10.11.cpp
#include <iostream>
//#define NDEBUG
#include <cassert>
using namespace std;
int main() {
  int n = 0;
  // asserts the value of even_num must be even
  assert(n != 0);
  int even_num = 20/n;
  cout << " Success " <<even_num<<endl;
  return 0;
}