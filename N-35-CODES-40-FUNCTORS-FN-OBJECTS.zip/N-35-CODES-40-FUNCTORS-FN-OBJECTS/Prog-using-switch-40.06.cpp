//Prog-using-switch-40.06.cpp 
#include <iostream>
using namespace std;

// The four arithmetic operations
float Plus(float a, float b) { return a + b; }
float Minus(float a, float b) { return a - b; }
float Multiply(float a, float b) { return a * b; }
float Divide(float a, float b) { return a / b; }

void Switch(float a, float b, char opCode) {
    float result;
    switch (opCode) { // execute operation
        case '+': result = Plus(a, b); break;
        case '-': result = Minus(a, b); break;
        case '*': result = Multiply(a, b); break;
        case '/': result = Divide(a, b); break;
    }
    cout << "Result of = " << result << endl;
}

int main() {
    float a = 10.5, b = 2.5;
    Switch(a, b, '+');
    Switch(a, b, '-');
    Switch(a, b, '*');
    Switch(a, b, '/');
    return 0;
}
