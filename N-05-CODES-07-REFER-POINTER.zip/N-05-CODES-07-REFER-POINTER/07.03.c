// program 07.03
#include <stdio.h>
void swap(int *, int *); // call-by-address
int main() { int a = 10, b = 15;
    printf("a= %d & b= %d to swap\n", a, b);
    swap(&a, &b); // Unnatural call
    printf("a= %d & b= %d on swap\n", a, b);
}
void swap(int *x, int *y) { int t;
    t = *x; *x = *y; *y = t;
}
/*a= 10 & b= 15 to swap
a= 15 & b= 10 on swap*/