//14-05-A-String-Class.cpp
#include <iostream>
#include <cstdlib>
#include <cstring>
using namespace std;
class String {size_t len_; //Container
              char *str_;  // Length
public: String(char *s) : str_(strdup(s)),//uses malloc
                          len_(strlen(str_))
                          {cout << "ctor:";print();}
                          ~String(){cout << "ctor:";print();
                              free(str_);//To match malloc() in strdup()
}
    void print(){cout<<"("<<str_<<":"
    << len_ << ")"<<endl;}
    size_t len(){return len_;}
    };
    int main(){String s="Hello";//Ctor called
        s.print();
        }
//.\14-05-A-String-Class.exe
//This comes out without producing any output