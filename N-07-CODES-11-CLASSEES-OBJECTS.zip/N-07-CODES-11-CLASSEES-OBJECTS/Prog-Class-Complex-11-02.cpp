#include <iostream>
using namespace std;

class Complex
 {public: //class
 double re,im;         //Data members
 };
int main()
{
    Complex c = {3.7 , 8.3};
//object c declared & initialized
    cout<<c.re<<" "<<c.im<<endl;//use by dot
}

