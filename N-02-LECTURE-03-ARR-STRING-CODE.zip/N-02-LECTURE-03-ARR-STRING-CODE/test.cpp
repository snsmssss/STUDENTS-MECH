#void List:: append (Node *p) { // friend of Node 
   if (!head) head = tail = p;
   else {
     tail->next = p;
     tail = tail->next;
   }
}
int main() { List l;            // Init, null list 
    Node n1 (1), n2(2), n3(3); // Few nodes
    l.append(&n1);            // Add nodes to list
    l.append(&n2);
    l.append(&n3);
    l.display();             // Show list
}
//1 2 3 
