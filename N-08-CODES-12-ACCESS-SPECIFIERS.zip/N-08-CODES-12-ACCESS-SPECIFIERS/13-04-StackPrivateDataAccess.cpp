//12-05-StackPrivateDataAccess.cpp
#include <iostream>
using namespace std;
class Stack{private: char *data_; int top_;
public: //Initialization and De-initialization
Stack(): data_(new char[100]),top_(-1){}
~Stack(){delete[] data_; }
//Stack LIFO member functions
int empty(){return (top_ == -1);}
void push(char x){data_[++top_]=x;}
void pop(){--top_;}
char top(){return data_[top_];}
};
int main(){ Stack s; char str[10]="PQRSTUVW";
for(int i=0; i<8; ++i)s.push(str[i]);
while(!s.empty()){cout << s.top();s.pop();}
}
//.\12-05-StackPrivateDataAccess.exe
//WVUTSRQP