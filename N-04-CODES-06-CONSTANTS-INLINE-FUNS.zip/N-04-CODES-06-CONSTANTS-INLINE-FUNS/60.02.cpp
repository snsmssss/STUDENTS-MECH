//  program 06.2
#include <iostream>
#include <cmath>
using namespace std;
const int TWO = 2;
const double PI = 4.0*atan(1.0);

int main() { int r= 10;
    // No replacement by CPP
    double peri = TWO * PI * r;
    cout << "Perimeter = " << peri << endl;
    }