#include <stdio.h>
typedef struct Stack { // struct Stack
char data[100]; // Container for elements
int top;        // Top of stack marker
} Stack;
// Codes for push(), pop(), top(), empty()
int main() {
    // Variable s declared
Stack s;
s.top = -1;
   // Using stack for solving problems
}
