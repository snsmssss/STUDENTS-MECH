#include <stdio.h>

int main() {
    int num;
    
    // Get input from the user
    do {
        printf("Enter any positive integer (or 0 for factorial of 0): ");
        scanf("%d", &num);
    } while (num < 0); // Allow 0 as a valid input

    int factorial;

    // Calculate factorial
    for (int i = 1; i <= num; i++) {
        factorial *= i;
    }

    printf("%d! = %d\n", num, factorial);
    return 0;
}

