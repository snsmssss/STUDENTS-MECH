// Prog-w-wo-Lambda-functor-40.16.cpp
#include <iostream> 
#include <vector>
#include <algorithm>
using namespace std; 
 
 struct isMultipleOf
 {
    int m_multi = 5;
 public:
    isMultipleOf(int multi) : m_multi(multi) {}
    bool operator()(int x)
    {
        return !(x% m_multi);
    
    }
 };
 int main()
 {
    vector<int> col {1,2,3,4,5,9,8,7,6,10,15,25};
    int multi = 5;
    int c;
    //c = count_if(col.begin(), col.end(),isMultipleOf(multi) );
    c = count_if(col.begin(), col.end(), [multi](int x){return !(x% multi);});
    cout << "Numbers in the vector that are multiple of   "<<multi <<" are "<< c << endl;
    return 0; 
 }
