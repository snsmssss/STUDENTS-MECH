#include <iostream>
using namespace std;

class A { public: virtual ~A() { } };
class B: public A { };
class C { public: virtual ~C() { } };

int main() { A a; B b; C c;
    //pA = 0; pC = dynamic_cast<C*>(pA);
    //cout << pA << "casts to "<< pC << ": Unrelated-cast: Valid for null" << endl;
    
   //fill the blanks 
    B* pB = &b; A *pA = ------------(pB);
    cout << pB << "casts to "<< pA << ": Up-cast: Valid" << endl;
    
    
    //fill the blanks
    pA = &a; pB = ------------(pA);
    cout << pA << "casts to "<< pB << ": Down-cast: Invalid" << endl;
    //fill the blanks
    pA = (A*)&c; C *pC = ----------(pA);
    cout << pA << "casts to "<< pC << ": Unrelated-cast: Invalid" << endl;
    
    
    pA = &a; void *pV = dynamic_cast<void*>(pA);
    cout << pA << "casts to " << pV << ": Cast-to-void: Valid" << endl;
// pA = dynamic_cast<A*>(pV); // error: 'void *': invalid expression type for dynamic_cast
} 
