//12-04-StackPublicDataAccess.cpp
#include <iostream>
#include <vector>
using namespace std;
class Stack{public: vector<char> data_; int top_;
public: int empty(){return(top_ == -1);}
void push(char x){data_[++top_]=x;}
void pop(){--top_;}
char top(){return data_[top_];}
};
int main(){ Stack s; char str[10]="PQRSTUVW";
s.data_.resize(100);//Exposed sizing
s.top_ = -1;            //Exposed init
for(int i=0; i<8; ++i)s.push(str[i]);
s.top_ = 2;
//prints on the screen WVUTSRQP, the reversed string
while(!s.empty()){cout << s.top();s.pop();}
//delete [] s.data_; //Exposed deallocation
}
//.\12-04-StackPublicDataAccess.exe
//WVUTSRQP