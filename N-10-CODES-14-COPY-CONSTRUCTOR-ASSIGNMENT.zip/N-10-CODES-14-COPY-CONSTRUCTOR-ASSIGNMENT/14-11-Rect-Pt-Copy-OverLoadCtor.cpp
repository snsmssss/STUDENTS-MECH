//14-11-Rect-Pt-Copy-OverLoadCtor.cpp
#include <iostream>
using namespace std;
class Point{int x_; int y_;public:
  Point(int x,int y):x_(x),y_(y){cout<<"Point ctor:"; print();
  cout<<endl;} //Ctor
  Point():x_(0),y_(0){cout<<"Point Dctor:"; print();
  cout<<endl;} //DCtor
  Point(const Point& p):x_(p.x_),y_(p.y_){cout<<"Point cctor:"; print();
  cout<<endl;} //CCtor
  ~Point(){cout<<"Point dtor:"; print();
  cout<<endl;} //Dtor
  void print(){cout << "(" <<x_<< "," <<y_ << ")";}}; //Class Point
class Rect{Point TL_, BR_; public: 
  Rect(int tlx, int tly, int brx, int bry):
      TL_(tlx, tly), BR_(brx,bry)//Ctor of Rect: 4 coords
  {cout<<"Rect ctor:"; print();cout<<endl;} //Uses Ctor for Pt
Rect(const Point& p_tl,const Point& p_br):TL_(p_tl),BR_(p_br) //Ctor of Rect:2pts
{cout<<"Rect ctor:"; print();cout<<endl;} //uses CCtor for pt
Rect(const Point& p_tl,int brx,int bry):TL_(p_tl),BR_(brx,bry)
//Ctor of Rect:Point+2 coords
{cout<<"Rect ctor:"; print();cout<<endl;} 
//DCtor of Rect://DCtor point CCtor for pt
Rect(){cout<<"Rect ctor:"; print();cout<<endl;}
 Rect(const Rect& r):TL_(r.TL_),BR_(r.BR_)//CCtor of Rect
 {cout<<"Rect cctor:"; print();cout<<endl;}//Uses CCtor for Pt
 ~Rect(){cout<<"Rect dtor:";print();cout<<endl;}//Dtor
 void print(){cout<<"[";TL_.print();cout<<" ";BR_.print();
              cout<<"]";}}; //Class Rect
 int main(){
  Rect r1(0,2,5,7);//Rect(int, int, int, int)
  Rect r2(Point(3,5),Point(6,9));//Rect(Point&,Point&)
  Rect r3(Point(2,2),6,4);//Rect(Point&,int,int)
  Rect r4;//Rect()
  return 0;
 }
  /*Point ctor:(0,2)           
Point ctor:(5,7)
Rect ctor:[(0,2) (5,7)]
Point ctor:(6,9)
Point ctor:(3,5)
Point cctor:(3,5)
Point cctor:(6,9)
Rect ctor:[(3,5) (6,9)]
Point dtor:(3,5)
Point dtor:(6,9)
Point ctor:(2,2)
Point cctor:(2,2)
Point ctor:(6,4)
Rect ctor:[(2,2) (6,4)]
Point dtor:(2,2)
Point Dctor:(0,0)
Point Dctor:(0,0)
Rect ctor:[(0,0) (0,0)]
Rect dtor:[(0,0) (0,0)]
Point dtor:(0,0)
Point dtor:(0,0)
Rect dtor:[(2,2) (6,4)]
Point dtor:(6,4)
Point dtor:(2,2)
Rect dtor:[(3,5) (6,9)]
Point dtor:(6,9)
Point dtor:(3,5)
Rect dtor:[(0,2) (5,7)]
Point dtor:(5,7)
Point dtor:(0,2)*/