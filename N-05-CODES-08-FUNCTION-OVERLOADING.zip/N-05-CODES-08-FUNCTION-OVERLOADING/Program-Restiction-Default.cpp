#include <iostream>
using namespace std;
void g(int, double, char='a');
void g(int, double f = 0.0, char ch);
void g(int i=0, double f, char ch);
void g(int i, double f, char ch)
    {
        cout <<i <<" "<< f << " " << ch <<endl;
    }
int main()
{
 int i = 5; double d = 1.2; char c = 'b';
    g();
    g(i);
    g(i,d);
    g(i,d,c);   

}