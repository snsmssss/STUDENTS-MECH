// Array_Malloc.c
#include <stdio.h>
#include <stdlib.h>

int main() { printf("Enter no. of elements");
    int count, sum = 0, i;
    scanf("%d", &count);

    int *arr = (int*) malloc
        (sizeof(int)*count);
    for(i = 0; i < count; i++){
        arr[i] = i; sum += arr[i];
    }
    printf("Array Sum:%d ", sum);
}
/*Enter no. of elements10
Array Sum:45*/