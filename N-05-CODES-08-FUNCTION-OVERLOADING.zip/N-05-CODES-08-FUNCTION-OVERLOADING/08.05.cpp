#include <iostream>
using namespace std;
int Area(int a, int b) { return (a * b); }
doubleArea(int a, int b) { return (a * b);}
// Error C2556: double Area(int,int): overloaded function differs only by return type
//              from int Area(int, int)
// Error C2371: Area: redefinition; different basic types
int main() {
    int x = 10, y = 12, z = 5, t;
    double f;

    t = Area(x, y);
    // Error C2568: =: unable to resolve function overload
    // Error C3861: Area: identifier not found
    cout << "Multiplication = "<< t << endl;
    f = Area(y, z); // Errors C2568 and C3861 as above
    cout << "Multiplication = " << f << endl;
}
/*Multiplication = 120
Multiplication = 60*/