//File Name: Program-class-rect-memb-fun-11-10.cpp
#include <iostream>
#include <cmath>
using namespace std;
class Point{public: int x; int y;}; 
class Rect {public: //Rect uses Point
Point TL; // Top Left Member of UDT
Point BR; // Bottom Right Member of UDT 
//Method
void computeArea(){//Parameter Implicit
	cout << abs((TL.x - BR.x)) *
                abs((TL.y - BR.y)); 
	}
};
int main(){Rect r = {{0,2},{5,7}};
    r.computeArea(); //Method invocation
}
// .\RectMembFun-11-10.exe
// 25
