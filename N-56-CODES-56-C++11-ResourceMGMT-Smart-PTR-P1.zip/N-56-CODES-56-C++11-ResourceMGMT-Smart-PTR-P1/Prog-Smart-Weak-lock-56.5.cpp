#include <iostream>
#include <memory>
using namespace std;
int main() {
    // weak_ptr     
    weak_ptr<int> wePtr1;
    {
        shared_ptr<int> shPtr1 = make_shared<int>(25);
        wePtr1 = shPtr1;
        if (auto sp = wePtr1.lock()) { // Lock weak_ptr to get shared_ptr
            cout << "Weak Pointer 1= " << *sp << endl;
        } else {
            cout << "Weak Pointer is expired.1" << endl;
        }
    }
    // After shared_ptr goes out of scope
    if (auto sp = wePtr1.lock()) {
        cout << "Weak Pointer 2= " << *sp << endl;
    } else {
        cout << "Weak Pointer is expired.2" << endl;
    }
    return 0;
}
