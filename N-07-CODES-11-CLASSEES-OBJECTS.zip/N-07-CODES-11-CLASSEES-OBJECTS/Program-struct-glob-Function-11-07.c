// File Name: Program-struct-glob-Function-11-07.c
#include <stdio.h>
#include <math.h>
// Type as alias
typedef struct Complex { double re, im; } Complex;
// Norm of Complex Number - global fn.
double norm(Complex c) { // Parameter explicit
    return sqrt(c.re*c.re + c.im*c.im); }
// Print number with Norm - global fn.
void print(Complex c) { // Parameter explicit
    printf("|%lf+j%lf| = ", c.re, c.im);
    printf("%lf", norm(c)); // Call global
}
int main() { Complex c = { 4.2, 5.3 };
print(c); // Call global fn. with c as param
}
/*
|4.200000+j5.300000| = 6.762396*/
