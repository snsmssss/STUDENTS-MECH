//13-09-ComplexOverloadedConstructor.cpp
#include <cmath>
#include<iostream>
using namespace std;

class Complex {private: double re_, im_; public:
Complex(double re ,double im):re_(re),im_(im){}// 2 params
Complex(double re ):re_(re),im_(0.0){}         // 1 param 
Complex():re_(0.0),im_(0.0){}                  // 0 param
     double norm(){return sqrt(re_*re_+im_*im_);}
     void print(){cout<<"|" <<re_ <<"+j" <<im_ << "|=" << norm()<<endl;}
                       };
int main()
{
    Complex c1(3.0,4.0),//Complex::Complex(doble,doble)
            c2(2.0),//Complex::Complex(doble)
            c3;//Complex::Complex()
    c1.print();
    c2.print();
    c3.print();
    return 0;
}
//.\13-09-ComplexOverloadedConstructor.exe
//|3+j4|=5
//|2+j0|=2
//|0+j0|=0