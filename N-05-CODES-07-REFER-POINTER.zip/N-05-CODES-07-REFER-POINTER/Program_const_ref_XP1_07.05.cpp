//Program_const_ref_XP1_07.05.cpp
#include <iostream>

using namespace std;
int Ref_const(const int &x) {
    return (x + 1); 
}
int main() 
{   
    int a = 10 , b;
    b = Ref_const(a);
    cout << "a = "<< a << " and" << " b = "<< b;
}
    /*a = 10 and b = 11*/