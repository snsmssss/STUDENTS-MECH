#include <iostream>
using namespace std;
class MyClass { int myPriMember_; public: int myPubMember_;
MyClass (int mPri, int mPub) : myPriMember_(mPri), myPubMember_(mPub) { }
    int getMember() const { return myPriMember_; }
    void setMember(int i) { myPriMember_ = i; }
    void print() const { cout << myPriMember_ << ", " << myPubMember_ << endl; }
};
int main() { MyClass myObj(0, 1); // non-const object
    const MyClass myConstObj(5, 6); // const object
    // non-const object can invoke all member functions and update data members
    cout << myObj.getMember() << endl;
    myObj.setMember(2);
    myObj.myPubMember_ = 3;
    myObj.print();
    // const object cannot allow any change
    cout << myConstObj.getMember() << endl;
    // myConstObj.setMember(7); // Cannot invoke non-const member functions
    // myConstObj.myPubMember = 8; // Cannot update data member
    myConstObj.print();
}
/*0
2, 3
5
5, 
6*/