//13-18-ComplexObjectLifeDynamic.cpp
#include <iostream>
#include <cmath>
using namespace std;
class Complex {private:double re_, im_;public:
Complex(double re = 0.0, double im = 0.0) : re_(re), im_(im)//Ctor
{cout << "Ctor: (" << re_ << "," << im_ << ")" << endl;}
~Complex(){cout<<"Dtor:("<<re_<<","<< im_<< ")"<<endl;}//Dtor
double norm(){return sqrt(re_ * re_ + im_ * im_);}
void print() {cout << "|" << re_ << "+j" << im_ << "| = " << norm() << endl;}
};
int main(){unsigned char buf[100]; //Buffer for placement of objects
    Complex* pc = new Complex(4.2,5.3);//new:allocates mem,calls Ctor
    Complex* pd = new Complex[2];//new:allocates memory
                    //calls default Ctor twice
    Complex* pe =new(buf)Complex(2.6,3.9);//placement new;only calls Ctor
                                    // No alloc of memory 
//Use Objects
    pc ->print();
    pd[0].print();pd[1].print();
    pe ->print();
// Release pf Objects - can be done in any order
delete pc;//delete : Calls Dtor release memory
delete [] pd;//delete Calls 2 Dtors , release memory
pe -> ~Complex();
}
/*Ctor: (4.2,5.3)
Ctor: (0,0)
Ctor: (0,0)
Ctor: (2.6,3.9)
|4.2+j5.3| = 6.7624
|0+j0| = 0
|0+j0| = 0
|2.6+j3.9| = 4.68722
Dtor:(4.2,5.3)
Dtor:(0,0)
Dtor:(0,0)
Dtor:(2.6,3.9)*/

