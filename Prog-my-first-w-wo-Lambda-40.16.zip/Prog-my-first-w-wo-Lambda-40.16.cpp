// Prog-my-first-Lambda-40.16.cpp
#include <iostream> 
#include <vector>
#include <algorithm>
using namespace std; 
 
 struct isEven
 {
    bool operator()(int x)
    {
        return !(x%2);
      
    }
 };
 int main()
 {
    vector<int> col {1,2,3,4,5,7,9,10,11,13,14};
    int c;
    //c = count_if(col.begin(), col.end(), isOdd());
    c = count_if(col.begin(), col.end(), [](int x){return !(x%2);});
    cout << "Numbers in the vector that are Even" << c << endl;
    return 0; 
 }
