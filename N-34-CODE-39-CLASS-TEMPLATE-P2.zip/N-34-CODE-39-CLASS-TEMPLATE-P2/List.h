
#ifndef _LIST_H 
#define __LIST_H
#include <vector> 
using namespace std;
template<class T> 
class List {
public:
	void put (const T &val) { items.push_back(val); }
i	nt length() { return items.size(); }		// vector<T>::size()
	bool find (const T &val) {
		for (unsigned int i = 0; i < items.size(); ++i) 
			if (items[i] == val) return true; // T must support operator==(). Its trait
		return false;
};
private:
	vector<T> items; 	// T must support T(), "T()), T(const t&) or move 
}	// Its traits
#endif // __LIST_H
//List is basic container class


