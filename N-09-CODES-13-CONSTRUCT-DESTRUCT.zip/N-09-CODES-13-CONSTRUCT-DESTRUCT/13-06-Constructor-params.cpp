//13-06-Constructor-params.cpp
#include <iostream>
#include <cmath>
using namespace std;
class Complex {private: double re_, im_;
public: 
      Complex(double re, double im): // constructor with parameters
      re_(re), im_(im) //Initializer list:parameters 2 initialize data members
      { }
      double norm(){ return sqrt(re_*re_ + im_*im_);}
      void print(){
        cout << "|" << re_ << "+j" << im_ << "| = ";
        cout << norm() << endl;
        }
      };
int main(){
Complex c(4.2,5.3);//Complex::Complex (4.2,5.3)
Complex d(1.6,2.9);//Complex::Complex (1.6,2.9)
c.print();
d.print();
}
/*|4.2+j5.3| = 6.7624
|1.6+j2.9| = 3.3121*/