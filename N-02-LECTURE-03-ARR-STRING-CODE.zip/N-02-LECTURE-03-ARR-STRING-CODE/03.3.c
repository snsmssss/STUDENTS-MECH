// Array_Macro.c
#include <stdio.h>
#include <stdlib.h>
#define MAX 100

int main() { int arr[MAX]; 
    printf("Enter no. of elements: ");
    int count, sum = 0, i;
    scanf("%d", &count);
    for(i = 0; i < count; i++){
        arr[i] = i; sum += arr[i];
    }
    printf("Array Sum: %d", sum);
}
/*Array Sum: 45*/
