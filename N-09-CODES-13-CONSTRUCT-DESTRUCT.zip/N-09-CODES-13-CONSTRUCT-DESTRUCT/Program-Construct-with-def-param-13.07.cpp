//13-07-ConstructDefParam.cpp
#include <cmath>
#include<iostream>
using namespace std;
class Complex {private: double re_, im_; public:
Complex(double re =0.0, double im = 0.0)://Constructor with default parameters
        re_(re),im_(im)   //Initiator List: parameters to initialize data members
        {}
        double norm(){return sqrt(re_*re_+im_*im_);}
     void print(){cout<<"|" <<re_ <<"+j" <<im_ << "|=" << norm()<<endl;}
};
int main(){
    Complex c1(4.2, 5.3),//Complex::Complex(4.2, 5.3)-- both parameters explict
            c2(4.2),//Complex::Complex(4.2,0.0)-- secound parameters defaults
            c3;//Complex::Complex(0.0,0.0)-both parameters defaults
    c1.print();
    c2.print();
    c3.print();
}
/*|4.2+j5.3|=6.7624
|4.2+j0|=4.2
|0+j0|=0*/