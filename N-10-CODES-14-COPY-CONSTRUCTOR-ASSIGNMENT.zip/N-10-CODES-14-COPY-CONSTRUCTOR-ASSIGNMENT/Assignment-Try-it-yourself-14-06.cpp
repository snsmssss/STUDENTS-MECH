//14-06.cpp
#include <iostream>
using namespace std;
char monthnames[][4]={ "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
char dayNames[][10] ={"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday" };
class Date {
    enum Month { Jan = 1, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec };
    enum Day { Mon, Tue, Wed, Thu, Fri, Sat, Sun };
    typedef unsigned int UNIT;
    UNIT date_; Month month_; UNIT year_;
public:
    Date(UNIT d, UNIT m,UNIT y) : date_(d),month_((Month)m), year_(y) { cout << "ctor: "; print(); }
    ~Date() { cout << "dtor: "; print(); }
    void print() { cout << date_ << "/" << monthnames[month_ - 1] << "/" <<year_ << endl; }
    bool valiDate() { /* check validaty */ return true; } // Not implemented
};
int main() {
    Date d(30, 7, 1961);
    d.print();
}
/*ctor: 30/Jul/1961
30/Jul/1961
dtor: 30/Jul/1961*/
