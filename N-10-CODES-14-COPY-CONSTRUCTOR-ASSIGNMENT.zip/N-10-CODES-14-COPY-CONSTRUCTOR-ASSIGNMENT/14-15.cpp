//14-15.cpp
#include <iostream>
#include <cmath>
using namespace std;
class Complex { double re_, im_; public:
     Complex(double re, double im) : re_(re), im_(im) { cout << "ctor: "; print(); } //Ctor
     Complex(const Complex& c) : re_(c.re_), im_(c.im_) { cout << "ccout: "; print(); }//CCtor
     ~Complex() { cout << "dtor: "; print();}                                        //Dtor
     Complex& operator=(const Complex& c)  //copy Assignment operator
     { re_ = c.re_; im_ = c.im_; cout << "copy: "; print();return *this; } //return *this for chaining
     double norm() { return sqrt(re_*re_ + im_*im_); }
     void print() { cout << "|" << re_ << "+j" << im_ << "| = " << norm() << endl; } }; //class Complex
int main() { Complex c1(4.2, 5.3), c2(7.9, 8.5); Complex c3(c2); // c3 copy constructed from c2
    c1.print(); c2.print(); c3.print();
    c2 = c1; c2.print();                                //copy Assignment operator
    c1 = c2 = c3; c1.print(); c2.print(); c3.print();  //copy Assignment chain 
}  
/*ctor: |4.2+j5.3| = 6.7624
ctor: |7.9+j8.5| = 11.6043
ccout: |7.9+j8.5| = 11.6043
|4.2+j5.3| = 6.7624
|7.9+j8.5| = 11.6043
|7.9+j8.5| = 11.6043
copy: |4.2+j5.3| = 6.7624
|4.2+j5.3| = 6.7624
copy: |7.9+j8.5| = 11.6043
copy: |7.9+j8.5| = 11.6043
|7.9+j8.5| = 11.6043
|7.9+j8.5| = 11.6043
|7.9+j8.5| = 11.6043
dtor: |7.9+j8.5| = 11.6043
dtor: |7.9+j8.5| = 11.6043
dtor: |7.9+j8.5| = 11.6043*/