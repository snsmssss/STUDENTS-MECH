// Program-overloading-UDT-09.02.cpp
#include <iostream>
using namespace std;
enum E { C0 , C1 , C2  };
E operator+(const E& a, const E& b) {//Overloaded operator +
    unsigned int uia = a, uib =b;
    unsigned int t = (uia*uia + uib*uib+2*uia*uib) ; // Redefined addition
    return (E) t;
}
int main() { E a = C1, b = C2;
    int x = -1;

    x = a + b; //Overloaded operator + for enum E
    cout << x << endl;
    }
    /*0*/
