//File Name: MemberFunction-11-08.cpp
#include <iostream>
#include <cmath>
using namespace std;
//Type as UDT
class Complex {public: double re, im;
 //Norm of Complex Number method
 double norm(){// Parameter implicit
   return sqrt(re*re + im*im);}
//print number with Norm method
void print(){//parameter implicit
 cout << "|" <<re<< "+j"<< im <<"| =";
 cout<<norm();// norm method
 }
};// end class complex
int main(){Complex c = {4.2 , 5.3};
c.print();// Invoke method print of c
}
//.\MemberFunction-11-08.exe
//|4.2+j5.3| =6.7624