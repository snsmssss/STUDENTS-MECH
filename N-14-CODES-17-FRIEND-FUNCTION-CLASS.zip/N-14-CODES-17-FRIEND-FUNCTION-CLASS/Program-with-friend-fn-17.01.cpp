// friend function
#include<iostream>
using namespace std;
class MyClass { int data_;
public:
	MyClass(int i): data_(i) { }
    friend void display(const MyClass& a);
};
void display(const MyClass& a) { // gbl. func. 
    cout << "data = " << a.data_; // Error 1
}
int main() { 
    MyClass obj (10);
    display(obj);
}
//data = 10