//12-06-StackPrivateVecDataAcc.cpp
#include <iostream>
#include <vector>
using namespace std;
class Stack{private: vector<char> data_; int top_;
public: //Initialization and De-initialization
Stack(): top_(-1){data_.resize(100);}
~Stack(){ };
//Stack LIFO member functions

int empty(){return (top_ == -1);}
void push(char x){data_[++top_]=x;}
void pop(){--top_;}
char top(){return data_[top_];}
};
int main(){ Stack s; char str[10]="PQRSTUVW";
for(int i=0; i<8; ++i)s.push(str[i]);
while(!s.empty()){cout << s.top();s.pop();}
}
//.\12-06-StackPrivateVecDataAcc.exe
//WVUTSRQP