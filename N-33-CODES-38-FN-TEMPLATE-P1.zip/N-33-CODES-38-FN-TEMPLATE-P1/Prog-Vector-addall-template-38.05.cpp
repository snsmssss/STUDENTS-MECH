//g++ prog02-template-class.cpp
//.\a.exe
//150
//150
//945
#include <iostream>
#include <vector>
#include <sstream>  
using namespace std;
template <typename T>
T addAll(std::vector<T> list)
{
    T count = 0;
    //auto: Automatically deduces the type of elem based
    //on the elements of the list.If list is a std::vector<int>,
    //then elem is deduced as int&.
    for(auto &elem: list)
    {
        count += elem;
    }
    return count;
}
template<> // Specialization
string addAll(vector<string> list)
{
    int count = 0;
    for(const string &elem: list)
    {
        for(const char & chr : elem)
        count += chr;
    }
    ostringstream Ostr;
    Ostr << count;
    string strCount= Ostr.str();
    return strCount;
}
int main()
{
    vector<int> IntVec = {10,20,30,40,50};
    vector<float> FloatVec = {10.0,20.0,30.0,40.0,50.0};
    vector<string> StringVec = {"abc","pqr","ghi"};
    cout << addAll(IntVec) << endl;
    cout << addAll(FloatVec) << endl;
    cout << addAll(StringVec) << endl;
    return 0;
}