//Prog-typedef-fun-ptr-40.05.cpp
#include <stdio.h>

typedef int (*pt2Function) (int, char, char);
int DoIt (int a, char b, char c);

int main() {
    pt2Function f = &DoIt; // DoIt

    int result = f(12, 'a', 'b');

    printf("%d", result);
    return 0;
}

int DoIt (int a, char b, char c) {
    printf("DoIt\n");
    return a + b + c;
}

//DoIt
//207