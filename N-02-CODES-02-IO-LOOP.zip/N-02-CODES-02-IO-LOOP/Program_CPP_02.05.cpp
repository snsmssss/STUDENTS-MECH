// bool_c++.cpp
#include <iostream>
using namespace std;
int main() {
    bool x = true;
    cout<<"bool is" << x;
}
