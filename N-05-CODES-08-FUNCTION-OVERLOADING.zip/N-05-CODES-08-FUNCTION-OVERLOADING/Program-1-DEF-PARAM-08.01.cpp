// program 08.01
#include <iostream>
using namespace std;
int IdentityFunction(int a = 10) { // Default value for parameter a
    return (a);
}

int main() {
    int x = 5, y;
    y = IdentityFunction(x); // Usual function call. Actual parameter taken as x = 5
    cout << "y = " << y << endl;

    y = IdentityFunction(); // Use default parameter. Actual parameter taken as 10
    cout << "y = " << y << endl;
}
/*y = 5
y = 10*/