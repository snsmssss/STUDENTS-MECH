//Assignment-Trace-of-Object-14.11.cpp
//Run and based on output fill the answers in empty box in Slide 23
#include <iostream>
using namespace std;
class Point
    {
    int x_; int y_;
    public:
        Point(int x,int y):x_(x),y_(y)
        {
            cout<<"Point ctor:";
            print();
            cout<<endl;
        } //Ctor
    
        Point():x_(0),y_(0)
        {
            cout<<endl;
            cout<<"Point Ctor:";
            print();
            cout<<endl;
        } //DCtor
  
        Point(const Point& p):x_(p.x_),y_(p.y_)
        {
            cout<<"Point cctor:";
            print();
            cout<<endl;
        } //CCtor
    
        ~Point()
        {
            cout<<"Point dtor:";
            print();
            cout<<endl;
        } //Dtor
    
        void print()
        {
            cout << "(" <<x_<< "," <<y_ << ")";
        }
    }; //Class Point ends here

class Rect
    {
        Point TL_, BR_;
        public: 
            Rect(int tlx, int tly, int brx, int bry):
            TL_(tlx, tly), BR_(brx,bry)//Ctor of Rect: 4 coords
            {
                cout<<"Rect4 ctor:";
                print();
                cout<<endl;
            } //Uses Ctor for Pt

        Rect(const Point& p_tl,const Point& p_br):TL_(p_tl),BR_(p_br) //Ctor of Rect:2 Points
            { 
                cout<<"Rect ctor:";
                print();
                cout<<endl;
            } //uses CCtor for pt

        Rect(const Point& p_tl,int brx,int bry):TL_(p_tl),BR_(brx,bry)//Ctor of Rect:Point+2 coords
            {
                cout<<"Rect ctor:";
                print();
                cout<<endl;
            } //DCtor of Rect://DCtor point CCtor for pt
        Rect()
        {
            cout<<endl;
            cout<<"Rect Ctor:";
            print();
            cout<<endl;

        }
        Rect(const Rect& r):TL_(r.TL_),BR_(r.BR_)//CCtor of Rect
        {
            cout<<"Rect cctor:";
            print();
            cout<<endl;
        }//Uses CCtor for Pt
 
        ~Rect()
        {
            cout<<"Rect dtor:";
            print();
            cout<<endl;
        }//Dtor
 
        void print()
        {
            cout<<"[";TL_.print();
            cout<<" ";BR_.print();
            cout<<"]";
        }
    }; //Class Rect ends here
 
    int main()
    {
        Rect r1(0,2,5,7);              //Rect(int, int, int, int)
        Rect r2(Point(3,5), Point(6,9));//Rect(Point&,Point&)  
        Rect r3(Point(2,2), 6, 4);       //Rect(Point&,int,int)        
        Rect r4;                      //Rect()
        return 0;
    }
    