//Program-struct-rect-globfun-11-9.c
#include <iostream>
#include <cmath>
using namespace std;
typedef struct{public: int x; int y;}point; 
typedef struct  {
point TL; // Top Left 
point BR; // Bottom Right 
}Rect;
// global function
void computeArea(Rect r){//Parameter explicit
    cout << abs(r.TL.x - r.BR.x) *
    abs(r.TL.y - r.BR.y); 
     }
int main(){Rect r = {{0,2},{5,7}};
    computeArea(r); //Method invocation
}
/*25*/
