#include <iostream>
using namespace std;

struct ...


void display(... *p)
{
    cout << p -> name << endl;
    ......
    ......


}
int main()
{
    
    ... ad = {"SamP", 37, "TN"};
    display(&ad);
    return 0;
}