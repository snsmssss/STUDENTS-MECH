// program 06.3
#include <iostream>
using namespace std;
#define SQUARE(x) x * x

int main() {
    int a = 3, b;
    b = SQUARE(a);
    cout << "Square = " << b << endl;
}
/*Square = 9*/