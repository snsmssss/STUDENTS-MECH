#include <iostream>
using namespace std;
class X{ public: int m1,m2;
    void f(int k1, int k2){ // sample member fn.
        m1 = k1;            // implicit access without -this- ptr
        this->m2 = k2;      // explicit access with -this- ptr
        cout << "Id = " << this << endl; // identity address of -this- ptr
    }
};
int main() { X a;
    a.f(200,300);
    cout << "Hello World"<<endl;
    //print Address of the object
    cout << "Address =" <<&a <<endl;
    cout << " a.m1 =" <<a.m1  <<" a.m2 =" <<a.m2 << endl;
    return 0;
}

