#include <iostream>
#include <string>
using namespace std;
class Data{string id_; public:
    Data(const string& id):id_(id)
    {cout << "Construct:" << id_ << endl;}
    ~Data()
    {cout << "Destruct: " <<id_ <<endl;}
};
class MyClass{
    static Data d1_;//Listed 1st
    static Data d2_;//Listed 1st
};
Data MyClass::d1_("obj_1");// Constructed 1st
Data MyClass::d2_("obj_2");// Constructed 2nd
int main(){return 0;}

