//  program 06.1
#include <iostream>
#include <cmath>
using namespace std;
#define TWO 2  // Manifest const
#define PI 4.0*atan(1.0) // Const expr.

int main() { int r= 10;
    double peri = TWO * PI * r;
    cout << "Perimeter = " << peri << endl;
    }
    /*Perimeter = 62.8319*/