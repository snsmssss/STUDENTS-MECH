// Sqrt.c
#include <stdio.h>
#include <math.h>
int main() { double x, sqrt_x;
printf("Input number: \n");
scanf("%lf", &x);
sqrt_x= sqrt(x);
printf("Sq. Root of %lf is:", x);
printf(" %lf\n", sqrt_x);
}


