#include <stdio.h>
int sum_digits(int n){
      int sum = 0;
      while(n > 0) {
        int m = n % 10;
        sum = sum + m;
        n = n / 10;
  }
  return sum;
}

int sum_factors(int n){
  int sum = 0;
  for(int i = 1; i < n; ++i){
    if(n % i == 0) {
      sum += i;
    }
  }
  return sum;
}

int main(int argc, char** argv){
  int number = 60;

  int sumf = sum_factors(number);
  int sumd = sum_digits(number);

  printf("sum of all factors = %d \n", sumf);
  printf("sum of all numbers = %d \n", sumd);
  
  return 0;
  }
