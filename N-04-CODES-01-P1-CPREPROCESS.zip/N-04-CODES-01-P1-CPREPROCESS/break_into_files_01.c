//Break this file into multiple files, compile and run
// File fact.h // Header for Factorial function 
#ifndef __FACT_H // Include Guard. Check 
#define __FACT_H // Include Guard. Define 
int fact(int); 
#endif // __FACT_H // Include Guard. Close 
// File fact.c // Implementation of Factorial function
//#include "fact.h" // User Header 
int fact(int n) 
{ if (0 == n) return 1;
else 
return n * fact(n-1); 
} 
// File main.c // Application using Factorial function
#include <stdio.h> // C Std. Library Header
//#include "fact.h" // User Header 
int main() { int n, f; 
printf("Input n:"); // From stdio.h 
scanf("%d", &n);
f = fact(n);
printf("fact(%d) = %d", n, f); // From stdiosh 
return 0; 
} 


