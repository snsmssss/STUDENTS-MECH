//14-10-A-Complex-Call-ByValue.cpp
#include <iostream>
#include <cmath>
using namespace std;
class Complex {double re_, im_; public:
    Complex (double re, double im):re_(re), im_(im)//Ctor
{cout <<"Complex ctor:"; print();}  
Complex(const Complex& c):re_(c.re_),im_(c.im_)// Copy Constructor    
{cout <<"copy ctor:"; print();}
~Complex(){cout <<"dtor:"; print();}
double norm(){return sqrt(re_*re_ + im_*im_);}
void print(){cout<< "|" << re_ << "+j"<< im_<<"|="<<norm()<<endl;}
};void Display(Complex c_param){//call by valu
cout << "Display: "; c_param.print();
}

int main(){Complex c(4.2,5.3);//Ctor Complex(double,double)
    Display(c);//copy Ctor called to copy c to c_param
}
//14-10-A-Complex-Call-ByValue.exe 
//Complex ctor:|4.2+j5.3|=6.7624 //Ctor of c in main()
//copy ctor:|4.2+j5.3|=6.7624 //Ctor c_param as copy of c,call Display()
//Display: |4.2+j5.3|=6.7624  //c_param
//dtor:|4.2+j5.3|=6.7624      //Dtor c_param on exit from Display()
//dtor:|4.2+j5.3|=6.7624      //Dtor of c on exit from main()