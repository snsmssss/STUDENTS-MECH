//Program_macro_06.07.cpp
#include <iostream>
using namespace std;
#define SQUARE(x) x * x
int main()
{
    int a = 3 , b;

    b = SQUARE(a + 1);

    cout << "Square  of a number = " << b << endl;

    return 0;
}