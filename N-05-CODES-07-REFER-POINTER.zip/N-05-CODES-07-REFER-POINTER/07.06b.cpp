// program 07.06b
#include <iostream>
using namespace std;
int &Function_Return_By_Ref (int &x) {
    cout << "x = " << x << " &x = " << &x << endl;
    return (x);
}
int main() { int a = 10;
    cout << "a = " << a << " &a = " << &a << endl;
    const int& b = // const optional
        Function_Return_By_Ref(a);
    cout << " b = " << b << " &b = " << &b << endl;
    }
    /*a = 10 &a = 0x90bc5ff984
    x = 10 &x = 0x90bc5ff984
    b = 10 &b = 0x90bc5ff980*/