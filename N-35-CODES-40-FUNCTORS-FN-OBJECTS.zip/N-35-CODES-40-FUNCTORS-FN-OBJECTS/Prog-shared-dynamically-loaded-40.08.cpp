//Prog-shared-dynamically-loaded-40.08.cpp 
