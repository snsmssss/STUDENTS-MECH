//Program-enum-09.06
#include <iostream> 
using namespace std; 
enum Printer_flags
{ready = 1, tray_empty = 2, busy = 3, out_of_black = 4,
  out_of_color = 5, error =6
}; 
int main() 
{ 
Printer_flags printer_status; 
printer_status=error;
if(printer_status != ready)
   cout << "Printer is out of Order-CODE= " << error <<endl; 
return 0; 
}