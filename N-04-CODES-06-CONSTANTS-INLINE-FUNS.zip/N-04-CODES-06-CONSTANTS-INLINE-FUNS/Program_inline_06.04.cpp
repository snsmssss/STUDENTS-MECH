// Program_inline_06.04.cpp
#include <iostream>  // Header replaced by CPP
using namespace std;

int main() {
    int a = 3, b;
    b = SQUARE(a); 
    cout << "Square = " << b << endl;
}
/*Square = 9*/