#include<iostream>
using namespace std;
class Glassdoor
{
    public: int a1,a2;
    void Gprint()
    {
        cout <<"division in class = "<<a1/a2<<endl;
    }
};
int main() { 
    int b1,b2;
    cin >> b1;
    cin >> b2;
    Glassdoor G = {b1,b2};

    G.Gprint();
    return 0;
}