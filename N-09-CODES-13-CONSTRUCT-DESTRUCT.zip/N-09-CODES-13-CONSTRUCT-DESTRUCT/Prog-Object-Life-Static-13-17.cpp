//13-17-ComplexObjectLifeStatic.cpp
#include <iostream>
#include <cmath>
using namespace std;
class Complex {private:double re_, im_;public:
Complex(double re = 0.0, double im = 0.0) : re_(re), im_(im)//Ctor
{cout << "Ctor: (" << re_ << "," << im_ << ")" << endl;}
~Complex(){cout<<"Dtor:("<<re_<<","<< im_<< ")"<<endl;}//Dtor
double norm(){return sqrt(re_ * re_ + im_ * im_);}
void print() {cout << "|" << re_ << "+j" << im_ << "| = " << norm() << endl;}
};
Complex c(4.2,5.3);//Static (global) object c
//constructred before main starts, Destructed after main ends
int main(){
    cout << "Main() starts"<<endl;
    Complex d(2.4);
    c.print();//use static object
    d.print();//use local object
}
/*Ctor: (4.2,5.3)
Main() starts
Ctor: (2.4,0)
|4.2+j5.3| = 6.7624
|2.4+j0| = 2.4
Dtor:(2.4,0)
Dtor:(4.2,5.3)*/
