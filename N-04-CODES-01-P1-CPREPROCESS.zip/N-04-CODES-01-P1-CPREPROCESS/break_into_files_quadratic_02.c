// File Solver.h
// User Header files
/*#ifndef __SOLVER_H // Include Guard. Check
#define __SOLVER_H // Include Guard. define
int quadraticEquationSolver(
    double, double, double, double*, double*);
#endif // __SOLVER_H // Include Guard. Close
// File Solver.c
// User Implementation files
#include <math.h> // C Std. Library Header
#include "Solver.h" // User Header*/
int quadraticEquationSolver(
    double a, double b, double c, // I/P Coeff.
    double* r1, double* r2)
    {  // O/P Roots
    // Uses double sqrt(double) from math.h
    //...
    return 0;
    }
// File main.c
// Application files
#include <stdio.h> // C Std. Library Header
#include "Solver.h"// User Headerint main() {
    double a, b, c, r1, r2;
    //...
    // Invoke the solver function from Solver.h
    int status = quadraticEquationSolver(a, b, c, &r1, &r2);
// int printf(char *format, ...) from stdio.h
printf("Soln. for %dx^2+%dx+%d=0 is %d %d", a, b, c, r1, r2);
//...
return 0;
}

