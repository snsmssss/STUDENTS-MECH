#include <iostream>
using namespace std;

class Student
{
   private:
      int rollno,marks;
   public:
      Student(int r, int m) : rollno(r),marks(m){
        cout << "Constructor" <<rollno<< endl;
      } 
      void display_rollno(){
         cout << "Student Roll Number ="<<this ->rollno<<endl;
         }
      ~Student() {
        cout << "Destructor" <<rollno<< endl;
      }
};
int main()
{
   Student s1(1001,20);
   s1.display_rollno();
   Student s2(1002,20);
   s2.display_rollno();
   return 0;
}