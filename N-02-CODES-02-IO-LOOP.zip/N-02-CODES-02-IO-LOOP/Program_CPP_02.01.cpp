/*Hello World.cpp*/
#include <iostream>
int main() {
    std::cout << "Hello World in C++";
    std::cout << std::endl;
    return 0;
}
