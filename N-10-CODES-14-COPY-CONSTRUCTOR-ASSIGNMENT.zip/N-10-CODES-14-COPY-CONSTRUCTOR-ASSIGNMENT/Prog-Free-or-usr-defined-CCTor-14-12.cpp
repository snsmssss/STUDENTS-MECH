//14-12-Complex-Free-Cp-Ctor.cpp
#include <iostream>
#include <cmath>
using namespace std;
class Complex {double re_, im_; public:
Complex(double re, double im):re_(re),im_(im){cout <<"ctor:";print();}//Ctor
Complex(const Complex& c):re_(c.re_),im_(c.im_)// Copy Constructor    
{cout <<"copy ctor:"; print();}
//Comment above 2 lines to get User Defined CCTor .Uncomment gives Free CCTor 
~Complex(){cout <<"dtor:"; print();}
double norm(){return sqrt(re_*re_ + im_*im_);}
void print(){cout<< "|" << re_ << "+j"<< im_<<"|="<<norm()<<endl;}};
void Display(Complex c_param){cout<<"Display: ";c_param.print();}
int main(){Complex c(4.2,5.3);//Ctor Complex(double,double)
    Display(c);//copy Ctor called to copy c to c_param
}
/*ctor:|4.2+j5.3|=6.7624
copy ctor:|4.2+j5.3|=6.7624
Display: |4.2+j5.3|=6.7624
dtor:|4.2+j5.3|=6.7624
dtor:|4.2+j5.3|=6.7624*/