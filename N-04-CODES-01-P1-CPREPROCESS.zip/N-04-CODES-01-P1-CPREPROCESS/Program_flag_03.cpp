//g++ -D FLAG Program_flag.cpp
//output 1
#include <iostream>

using namespace std;
int main()
{

    //printf("FLAG vlaue %d\n", z);
    cout << (FLAG == 1) << endl;
    return 0;
}