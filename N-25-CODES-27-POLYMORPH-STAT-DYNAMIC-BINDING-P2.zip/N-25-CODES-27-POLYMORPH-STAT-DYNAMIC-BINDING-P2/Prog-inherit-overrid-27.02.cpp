#include<iostream>
using namespace std;
class B { public: void f() { } 
};
class D:public B { public: void f() { } 
};
int main()
{ B b;
  D d; 
  b.f(); // B::f()
  d.f(); // D::f()   Overridden
        // masks the base class function
}

