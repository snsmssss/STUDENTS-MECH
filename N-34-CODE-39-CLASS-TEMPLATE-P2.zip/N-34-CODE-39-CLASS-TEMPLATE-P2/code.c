
#ifndef _LIST_H 
#define __LIST_H
#include <vector> 
using namespace std;
template<class T> 
class List {
public:
	void put (const T &val) { items.push_back(val); }
i	nt length() { return items.size(); }		// vector<T>::size()
	bool find (const T &val) {
		for (unsigned int i = 0; i < items.size(); ++i) 
			if (items[i] == val) return true; // T must support operator==(). Its trait
		return false;
};
private:
	vector<T> items; 	// T must support T(), "T()), T(const t&) or move 
}	// Its traits
#endif // __LIST_H
List is basic container class


-------------------------------------------------

#ifndef __SET_H
#define __SET_H
#include "List.h"

template<class T>
class Set {
public:
    Set() { };
    virtual ~Set() { };
    virtual void add(const T &val);

    int length(); // List<T>::length()

    bool find(const T &val); // List<T>::find()
private:
    List<T> items; // Container List<T>
};

template<class T>
void Set<T>::add(const T &val) {
    if (items.find(val)) return; // Don’t allow duplicate
    items.put(val);
}

template<class T> int Set<T>::length() { return items.length(); }
template<class T> bool Set<T>::find(const T &val) { return items.find(val); }

#endif // __SET_H

// Set is a base class for a set
// Set uses List for container

---------------------------------------------

#ifndef __BOUND_SET_H
#define __BOUND_SET_H

#include "Set.h"

template<class T>
class BoundSet: public Set<T> {
public:
    BoundSet(const T &lower, const T &upper);
    void add(const T &val); // add() overridden to check bounds
private:
    T min;
    T max;
};

template<class T> 
BoundSet<T>::BoundSet(const T &lower, const T &upper): min(lower), max(upper) { }

template<class T> void BoundSet<T>::add(const T &val) {
    if (find(val)) return; // Set<T>::find()
    if ((val <= max) && (val >= min)) // T must support operator<=() and operator>=(). Its trait
        Set<T>::add(val); // Uses add() from parent class
}

#endif // __BOUND_SET_H

// BoundSet is a specialization of Set
// BoundSet is a set of bounded items

----------------------------------------------------------

Templates and Inheritance Example: Bounded Set Application

#include <iostream>
using namespace std;
#include "BoundSet.h"

int main() {
    BoundSet<int> bsi(3, 21); // Allow values between 3 and 21
    Set<int> *setptr = &bsi;

    for (int i = 0; i < 25; i++)
        setptr->add(i); // Set<T>::add(const T&) is virtual

    if (bsi.find(4)) // Within bound
        cout << "We found an expected value\n";

    if (!bsi.find(0)) // Outside lower bound
        cout << "We found NO unexpected value\n";

    if (!bsi.find(25)) // Outside upper bound
        cout << "We found NO unexpected value\n";
}

We found an expected value
We found NO unexpected value
We found NO unexpected value

// Uses BoundSet to maintain and search elements

