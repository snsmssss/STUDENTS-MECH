//16-01-static-data-mem-v2.cpp 

#include <iostream>
using namespace std;
class MyClass{static int x; // static
public:
    void get() { x = 15;}
    void print(){x = x+100;
        cout << "x = " << x<< endl;
    }
};
int MyClass::x = 0;//Defin static data member
int main(){
    MyClass obj1, obj2; // Have distinct x
    obj1.get(); obj2.get();
    //obj1.print(); obj2.print();
    obj2.print();
    
    return 0;
}
//.\16-01-static-data-mem.exe    
//x = 25
//x = 35