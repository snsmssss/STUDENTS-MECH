#include <iostream>
using namespace std;
int main()
{
    int a[] = { 8, 6, 7};
    int *p = a; // pointing to 8
    //I can use addition ++ or subtraction --
    for (int i =0; i < 3; i++)
    {
        cout << *p << endl;
        p++;
    }
    return 0;
}