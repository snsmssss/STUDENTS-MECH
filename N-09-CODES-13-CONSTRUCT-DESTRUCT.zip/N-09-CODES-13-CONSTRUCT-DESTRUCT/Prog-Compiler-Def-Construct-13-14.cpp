//13-14-CompDefaultConstFree.cpp
#include <iostream>
#include <cmath>
using namespace std;
class Complex {private:double re_, im_;//privat data
public://No construct given by user.compiler provide free one
    double norm() {return sqrt(re_ * re_ + im_ * im_);}
    void print() {
    cout<< "|"<< re_ << "+j"<< im_ << "|= "<< norm() << endl;}
    void set(double re, double im) {re_=re;im_=im;}
    };
int main(){Complex c;//Free constructr fm compiler.Init with garbage
    c.print(); // Print initial value garbage
    c.set(4.2,5.3);//Set real & imaginary values
    c.print(); // Print Set values
    return 0;
}//Free Destructor from compiler
//13-14-CompDefaultConstFree.exe
//|0+j3.95253e-323|= 0
//|4.2+j5.3|= 6.7624