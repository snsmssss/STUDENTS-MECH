// Add_Num_C++.cpp
#include <iostream>
int main() { int a, d;
std:: cout << " Input two numbers:\n";
std::cin >> a >> b;
int sum= a + b; // Declaration of sum
std::cout << "Sum of " << a << " and " << b << " is: " << sum << std::endl;
}

