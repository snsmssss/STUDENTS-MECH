//Program_swap_07.04.cpp
#include <iostream>
using namespace std;
void swap(int&, int&); // call-by-reference
int main() { int a = 10, b = 15;
    cout<<"a= "<<a<<" & b= "<<b<<"to swap"<<endl;
    swap(a, b);     // Natural call
    cout<<"a= "<<a<<" &b= "<<b<<"on swap"<<endl;
}
void swap(int &x, int &y) { int t;
    t = x; x = y; y = t;
}
/*a= 10 & b= 15 to swap
  a= 15 & b= 10 on swap*/