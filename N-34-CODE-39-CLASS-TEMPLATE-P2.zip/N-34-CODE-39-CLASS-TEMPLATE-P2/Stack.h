//Stack.h
class Stack{
    char data_[100];
    int top_;
public:
    Stack(): top_(-1){ }
    ~Stack() { }
    void push(const char& item)
    {data_[++top_] = item;}

    void pop()
    {--top_;}

    const char& top() const
    {return data_[top_];} 

    bool empty() const
    {return data_[top_];}  
};