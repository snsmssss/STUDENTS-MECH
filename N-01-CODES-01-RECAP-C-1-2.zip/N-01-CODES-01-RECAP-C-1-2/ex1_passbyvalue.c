int funct(int x, int y) {
    ++x; 
    ++y; 
    return (x + y); // Formal parameters (x, y) are modified inside the function
}

int main() { 
    int a = 5, b = 10, z;
    printf("a = %d, b = %d\n", a, b);  // Prints: a = 5, b = 10

    z = funct(a, b);  // Call by value. a copied to x, b copied to y.
                      // x becomes 6, y becomes 11 inside funct.

    printf("funct = %d\n", z);  // Prints: funct = 17 (6 + 11)

    printf("a = %d, b = %d\n", a, b);  // Actual parameters unchanged: a = 5, b = 10
    return 0;
}
