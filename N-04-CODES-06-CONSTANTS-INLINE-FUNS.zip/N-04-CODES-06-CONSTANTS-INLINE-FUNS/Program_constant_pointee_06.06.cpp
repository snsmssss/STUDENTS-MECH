//  Program_const_pointee_06.06.cpp
#include <iostream>
using namespace std;

int main(void)
{
    int a = 10;
    const int* ptr = &a;

    cout << "value at ptr is  : "<< *ptr <<endl;
    //printf("\n value at ptr is  : [%d]\n",*ptr);

    cout << "Address pointed by ptr is  : "<< ptr << endl;
    //printf("\n Address pointed by ptr  : [%p]\n",(unsigned int*)ptr);

    *ptr = 11;

    return 0;
}
