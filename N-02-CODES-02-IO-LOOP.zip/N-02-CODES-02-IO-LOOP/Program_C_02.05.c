//bool.c
#include <stdio.h>
#include <stdbool.h>
int main() {
    bool x = true;
    printf("bool is %d\n", x);
}
