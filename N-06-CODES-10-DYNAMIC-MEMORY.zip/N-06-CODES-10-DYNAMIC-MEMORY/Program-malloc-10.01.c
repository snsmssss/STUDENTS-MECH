// Program 10.01
#include <stdio.h>
#include <stdlib.h>
int main() { 
    int *p = (int *)malloc(sizeof(int));
    *p = 5;
    printf("%d" , *p);  // Prints: 5
    free(p);
}
/*5*/