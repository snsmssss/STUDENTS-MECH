#ifndef __SET_H
#define __SET_H
#include "List.h"

template<class T>
class Set {
public:
    Set() { };
    virtual ~Set() { };
    virtual void add(const T &val);

    int length(); // List<T>::length()

    bool find(const T &val); // List<T>::find()
private:
    List<T> items; // Container List<T>
};

template<class T>
void Set<T>::add(const T &val) {
    if (items.find(val)) return; // Don’t allow duplicate
    items.put(val);
}

template<class T> int Set<T>::length() { return items.length(); }
template<class T> bool Set<T>::find(const T &val) { return items.find(val); }

#endif // __SET_H

// Set is a base class for a set
// Set uses List for container

