

#ifndef __BOUND_SET_H
#define __BOUND_SET_H

#include "Set.h"

template<class T>
class BoundSet: public Set<T> {
public:
    BoundSet(const T &lower, const T &upper);
    void add(const T &val); // add() overridden to check bounds
private:
    T min;
    T max;
};

template<class T> 
BoundSet<T>::BoundSet(const T &lower, const T &upper): min(lower), max(upper) { }

template<class T> void BoundSet<T>::add(const T &val) {
    if (find(val)) return; // Set<T>::find()
    if ((val <= max) && (val >= min)) // T must support operator<=() and operator>=(). Its trait
        Set<T>::add(val); // Uses add() from parent class
}

#endif // __BOUND_SET_H

// BoundSet is a specialization of Set
// BoundSet is a set of bounded items

----------------------------------------------------------
//Templates and Inheritance Example: Bounded Set Application


