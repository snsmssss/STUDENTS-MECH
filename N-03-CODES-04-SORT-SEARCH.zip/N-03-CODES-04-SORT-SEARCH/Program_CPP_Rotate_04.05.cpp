// 04.05.cpp
#include <iostream>
#include <algorithm> // rotate function
using namespace std;

int main() {
    int data[] = {1, 2, 3, 4, 5};
    rotate(data, data+2, data+5);
    for(int i = 0; i <5; ++i)
        cout << data[i] << " ";
    return 0;
}
/*3 4 5 1 2 */