//13-16-CompObjectLifeAutoArray.cpp
#include <iostream>
#include <cmath>
using namespace std;
class Complex {private:double re_, im_;public:
Complex(double re = 0.0, double im = 0.0) : re_(re), im_(im)
{cout << "Ctor: (" << re_ << "," << im_ << ")" << endl;}
~Complex(){cout<<"Dtor:("<<re_<<","<< im_<< ")"<<endl;}
void opComplex(double i){re_ += i;im_ += i;}//Some ops wit Complex
double norm(){return sqrt(re_ * re_ + im_ * im_);}
void print() {cout << "|" << re_ << "+j" << im_ << "| = " << norm() << endl;}
};
int main(){Complex c[3];
    for(int i=0; i < 3; ++i){c[i].opComplex(i);c[i].print();}
}
//13-16-CompObjectLifeAutoArray.exe
//Ctor: (0,0)
//Ctor: (0,0)
//Ctor: (0,0)
//|0+j0| = 0
//|1+j1| = 1.41421
//|2+j2| = 2.82843
//Dtor:(2,2)
//Dtor:(1,1)
//Dtor:(0,0)