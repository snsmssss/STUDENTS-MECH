#include <iostream>
using namespace std;

template <typename T>


class Less_than
{
    const T val; // value to compare against
    public:
            Less_than(const T& v):val(v){}
            bool operator()(const T& x) 
            const{return x < val;} // call operator
};

   
int main()
{
    Less_than<int> Iti {42}; // Iti(i) will compare i to 42 using < 
    Less_than<string> Its {"CERN"};// same way Its(s) will compare 
// we can call such an object , just as we call a function
    bool b1 = Iti(50);
    cout << "50 is less than 42 ?" << b1 << endl;

    

    return 0;
}


