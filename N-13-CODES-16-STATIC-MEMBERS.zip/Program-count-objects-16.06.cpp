//16-06-count-objects.cpp
#include <iostream>
#include <string>
using namespace std;
class MyClass{string id_;//object ID
    static int nObjCons_,nObjDes_;//Object history
public:
    MyClass(const string& id):id_(id)
    { ++nObjCons_;
    cout << "ctor: "<<id_<<"";getObjLive();}
    ~MyClass(){ ++nObjDes_;
    cout << "dtor: "<<id_<<"";getObjLive();}
    static int getObjConstructed()
    {return nObjCons_;}
    static int getObjDestructed()
    {return nObjDes_;}
    //Get number of live objects
    static int getObjLive(){
        int nLive = nObjCons_ - nObjDes_;
        cout<<"Live Objects =" <<nLive << endl;
        return nLive; } };
int MyClass::nObjCons_ = 0; 
int MyClass::nObjDes_ = 0;  
int dummy1(MyClass::getObjLive());//Before main()
MyClass sObj("sObj");
int dummy2(MyClass::getObjLive());//Before main()
int main(){MyClass::getObjLive();
    MyClass aObj("aObj");
    MyClass *dObj = new MyClass("dObj");
    {   MyClass bObj("bObj");
        delete dObj; }
    MyClass::getObjLive(); }
