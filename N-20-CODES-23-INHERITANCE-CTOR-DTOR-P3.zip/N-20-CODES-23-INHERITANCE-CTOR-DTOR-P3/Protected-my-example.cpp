//Protected-my-example.cpp
#include <iostream>
using namespace std;
class Car
{
    protected:
        int engine_;
    public:
        int mileage_;
Car(int e_,int m_):
engine_(e_), mileage_(m_){}

    ~Car(){}
};
class model: public Car
{
    public:
        int seating_;
        model(int e_,int m_, int s_):
Car(e_,m_),seating_(s_){}
~model(){}
        int rate_the_car()
{
        int final_rating_;
             if(engine_ > 2 && mileage_>15) 
                {
                    if(seating_ > 4)
                         final_rating_=5;
                    else
                        final_rating_=4; 
                }
            else 
            {
                final_rating_=3;
             }
            return final_rating_;
        }
};
int main()
{
    Car Maruti(3, 18);
    model swift(3, 18, 5); 
    cout << "The Rating for Car Maruti and
 Model Swift=<< swift.rate_the_car()<< endl;
    return 0;}
