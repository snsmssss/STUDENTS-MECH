// 05.03.cpp 
// use ddd debugger to solve the error in the code 
#include <iostream>
#include <stack> // Library codes
using namespace std;

int main() { char str[10]= "ABCDE";
    stack<char> s; // stack class

    for(int i = 0; i < 5 ; i++)
        s.push(str[i]);
    cout << "Reversed String: ";
    while (!s.empty()) {
        cout << s.top(); s.pop();
    }
}
/*Reversed String: EDCBA*/