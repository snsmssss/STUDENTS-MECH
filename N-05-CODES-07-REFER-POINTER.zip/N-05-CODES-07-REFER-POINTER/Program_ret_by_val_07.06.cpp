// Program_ret_by_val_07.06.cpp
#include <iostream>
using namespace std;
int Function_Return_By_Val (int &x) {
    cout << "x = " << x << " &x = " << &x << endl;
    return (x);
}
int main() { int a = 10;
    cout << "a = " << a << " &a = " << &a << endl;
    const int& b = // const needed. Why?
        Function_Return_By_Val(a);
    cout << " b = " << b << " &b = " << &b << endl;
    }
    /*a = 10 &a = 0xd3b1dffe04
    x = 10 &x = 0xd3b1dffe04
    b = 10 &b = 0xd3b1dffe00*/ // Reference to temporary