//14-01-Order-Initialize-DataMembers.cpp
#include <iostream>
using namespace std;
int init_m1(int m){//Func to init m1_
    cout<<"Init m1_: "<<m<<endl;
    return m;
}
int init_m2(int m){//Func to init m1_
    cout<<"Init m2_: "<<m<<endl;
    return m;
}
class X{ int m1_;//Initialize 1st
         int m2_;//Initialize 2nd
public: X(int m1, int m2):
        m1_(init_m1(m1)), //Called 1st
        m2_(init_m2(m2)) //Called 2nd
        {cout << "Ctor:"<<endl;}
        ~X() {cout << "Ctor:"<<endl;}};
        int main(){X a(2,3);return 0;}
//.\14-01-Order-Initialize-DataMembers.exe
//Init m1_: 2
//Init m2_: 3
//Ctor:
//Ctor: