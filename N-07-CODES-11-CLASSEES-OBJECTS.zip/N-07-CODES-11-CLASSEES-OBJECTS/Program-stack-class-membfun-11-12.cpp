#include <iostream>
using namespace std;
class Stack{public:
char data_[100]; int top_;
//Member Functions
bool empty() { return top_ == -1
;}
char top() {return data_[top_];}
void push(char x){data_[++top_] = x;}
void pop() { --top_;}
};
//.\StackMembFun-11-12.exe
//Reversed String =EDCBA

int main(){Stack s; s.top_ = -1;
char str[10] = "ABCDE"; int i; int count = 5;
for ( i = 0; i < count; i++)s.push(str[i]);
cout << "Reversed String =";
while (!s.empty()){
cout << s.top(); s.pop();
}

}

