#include <iostream>
using namespace std;

// Function to calculate the factorial of a number
int factorial(int n) {
    if (n == 0 || n == 1) {
        return 1;
    }
    int result = 1;
    for (int i = 2; i <= n; ++i) {
        result *= i;  // Bug: This will overflow for larger values of n
    }
    return result;
}

// Function to store factorials of numbers from 1 to n in an array
void storeFactorials(int arr[], int n) {
    for (int i = 0; i <= n; ++i) {  // Bug: This causes an out-of-bounds access when i == n
        arr[i] = factorial(i);
    }
}

int main() {
    int n;

    cout << "Enter a positive integer: ";
    cin >> n;

    if (n <= 0) {
        cout << "Invalid input. Exiting." << endl;
        return 1;
    }

    // Dynamically allocate array to store factorials
    int* factorials = new int[n];

    // Store factorials in the array
    storeFactorials(factorials, n);

    // Output the stored factorials
    cout << "Factorials from 0 to " << n - 1 << " are: " << endl;
    for (int i = 0; i < n; ++i) {
        cout << "Factorial of " << i << " is " << factorials[i] << endl;
    }

    // Clean up memory
    delete[] factorials;

    return 0;
}

