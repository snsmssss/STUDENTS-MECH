//14-14.cpp
#include <iostream>
#include <cstdlib>
#include <cstring>
using namespace std;
class String { public: char *str_; size_t len_;
    String(const char *s) : str_(strdup(s)), len_(strlen(str_)) { }       //Ctor
    String(const String& s) :str_(strdup(s.str_)), len_(s.len_) { } //CCtor: User provided
    ~String() { free(str_); }                                       //Dtor
    void print() { cout << "(" << str_ << ": " << len_ << ")" << endl;}
};
void strToUpper(String a) { // Make the string uppercase
    for (int i = 0; i < a.len_; ++i) { a.str_[i] = toupper(a.str_[i]); }
    cout << "strToUpper: "; a.print();
} // a.~String() is invoked releasing a.str_ and invalidating  s.str_ = a.str_
int main() { String s = "partha"; s.print(); strToUpper(s); s.print();} //Last print
/*(partha: 6)
(partha: 6)
strToUpper: (PARTHA: 6)
(partha: 6)*/
   
    