#include <stdio.h>
    int main()
    {
    
    long double start;
    long double end;
    long double step;

    printf("Enter the value for start: ");
    scanf("%Lf", &start);
    printf("Enter the value for end: ");
    scanf("%Lf", &end);
    printf("Enter the value for step: ");
    scanf("%Lf", &step);

    while(start != end)
       {
       
        printf("%Lf\n", start);
        start += step;
        }
     
    return 0;
    }

