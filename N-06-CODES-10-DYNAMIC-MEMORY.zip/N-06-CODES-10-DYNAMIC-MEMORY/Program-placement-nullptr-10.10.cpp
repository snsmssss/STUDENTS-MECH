#include <iostream>
using namespace std;
int main()
{
    int * ptr = nullptr;
    if (ptr ==nullptr)
        cout << "pointer is currently null" <<endl;
    else
        cout << "pointer is currently not null" <<endl;
    return 0;
}