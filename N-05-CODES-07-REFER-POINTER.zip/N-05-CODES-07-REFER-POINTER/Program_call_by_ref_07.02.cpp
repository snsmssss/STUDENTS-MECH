// program 07.02
#include <iostream>
using namespace std;
void Function_under_param_test( // Function prototype
    int&, // Reference parameter
    int); // Value parameter

int main() { int a = 20;
    cout << "a = " << a << ", &a = " << &a << endl << endl;
    Function_under_param_test(a, a); // Function call
}
void Function_under_param_test(int &b, int c) { // Function definition
    cout << "b = " << b << ", &b = " << &b << endl << endl;
    cout << "c = " << c << ", &c = " << &c << endl << endl;
    }
    /*a = 20, &a = 0x1299ffa6c
      b = 20, &b = 0x1299ffa6c   // Address of b is same as a as b is a reference of a 
      c = 20, &c = 0x1299ffa48*/ // Address different from a as c is a copy of a