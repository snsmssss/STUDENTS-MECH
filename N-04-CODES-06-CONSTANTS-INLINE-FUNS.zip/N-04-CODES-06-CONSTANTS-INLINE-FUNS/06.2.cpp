//  program 06.2
#include <iostream>
#include <cmath>
using namespace std;
#define TWO 2  
#define PI 4.0*atan(1.0) 

int main() { int r= 10;
// Replace by CPP
    double peri = 2* 4.0*atan(1.0) * r;
    cout << "Perimeter = " << peri << endl;
    }
    /*Perimeter = 62.8319*/