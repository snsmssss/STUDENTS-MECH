// Sqrt_c++.cpp
#include <iostream>

using namespace std;
int main() { double x;
    cout << "Input number:" <<endl;
    cin >> x;
    double sqrt_x = sqrt(x);
    cout << "Sq. Root of " << x;
    cout << " is: " << sqrt_x << endl;
    }
