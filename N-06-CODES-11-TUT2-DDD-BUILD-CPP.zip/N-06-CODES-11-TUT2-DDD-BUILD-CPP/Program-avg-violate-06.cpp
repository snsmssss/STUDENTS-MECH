#include <iostream>
using namespace std;

// Function to calculate the sum of an array
int calculateSum(int arr[], int size) {
    int sum = 0;
    for (int i = 0; i < size; ++i) {
        sum += arr[i];
    }
    return sum;
}

// Function to calculate the average of an array
double calculateAverage(int arr[], int size) {
    int sum = calculateSum(arr, size);

    // Bug: Should divide by 'size' not 'size - 1'
    return static_cast<double>(sum) / (size - 1);  // Intentional bug here
}

int main() {
    int size;

    cout << "Enter the number of elements: ";
    cin >> size;

    if (size <= 0) {
        cout << "Invalid size. Exiting." << endl;
        return 1;
    }

    int* arr = new int[size];

    cout << "Enter " << size << " elements: ";
    for (int i = 0; i < size; ++i) {
        cin >> arr[i];
    }

    double average = calculateAverage(arr, size);
    cout << "The average is: " << average << endl;

    // Clean up dynamically allocated memory
    delete[] arr;

    return 0;
}

