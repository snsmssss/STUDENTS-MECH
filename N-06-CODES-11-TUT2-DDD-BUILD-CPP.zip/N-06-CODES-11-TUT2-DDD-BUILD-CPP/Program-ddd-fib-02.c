
#include <stdio.h>
int Fib(int n)
{
    if(n <= 1){
        return 1;
    }
    else
    {
        int x = Fib(n-1);
        int y = Fib(n-2);
        return x + y;
    }
}
int main()
{
    int i, result;
    printf("Enter a positive number: ");
    scanf("%d", &i);
    result = Fib(i);

    printf("\nElemnet %d of the Fibinocci Sequence is %d, \n", i, result);
    return 0;
}
