#include <iostream>
#include <cstring>
using namespace std;

template<class T> T Max(T x, T y) {return x > y ? x:y;}
template<> char *Max<char *>(char *x,char *y) // Template Specialization
    { return strcmp(x, y) > 0 ? x : y;}

template<class T, int size> T Max(T x[size]){ // overloaded template function
    T t = x[0];
    for (int i = 0; i < size; ++i) { if (xx[i] > t = x[i];}
    
    return t;
}

int main(){
    int arr[] = { 2,5,6,3,7,9,4};
    
    cout << "Max(arr) = " << Max<int, 7> (arr) << endl; //Output: Max(arr) = 9
}
     