    //15-1.cpp
#include <iostream>
using namespace std;
class MyClass { int myPriMember_;
public: int myPubMember_;
     MyClass(int mPri, int mPub) : myPriMember_(mPri), myPubMember_(mPub) { }
     int getMember() { return myPriMember_; }
     void setMember(int i) { myPriMember_ = i; }
     void print() { cout << myPriMember_ << ", " << myPubMember_ <<endl; }
};
int main() { MyClass myObj(0, 1);      //non-constant object
    cout << myObj.getMember() << endl;
    myObj.setMember(2);
    myObj.myPubMember_ = 3;
    myObj.print();
} 
//0
//2, 3