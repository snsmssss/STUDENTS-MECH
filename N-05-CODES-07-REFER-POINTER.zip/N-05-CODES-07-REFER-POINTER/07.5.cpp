// program 07.5
#include <iostream>
using namespace std;
int Ref_const(const int &x) {
    ++x;        // Not allowed
    return (x);
}
int main() { int a = 10, b;
    b = Ref_const(a);
    cout << "a = " << a <<" and"
         << "b = " << b;
}
/*increment of read-only reference 'x'*/