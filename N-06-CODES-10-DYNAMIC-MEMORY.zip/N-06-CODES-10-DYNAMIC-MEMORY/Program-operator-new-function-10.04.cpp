// Program-operator-new-function-10.04.cpp
#include <iostream>
#include <cstdlib>
using namespace std;
int main() {
    int *p = (int *)operator new(sizeof(int));
    *p = 5;
    cout << *p; // Prints: 5
    operator delete(p);
}
/*5*/