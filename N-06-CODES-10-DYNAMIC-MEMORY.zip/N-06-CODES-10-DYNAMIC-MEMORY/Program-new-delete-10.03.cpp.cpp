// Program-new-delete-10.03.cpp
#include <iostream>
using namespace std;
int main() { 
 int *p = new int(5);
 cout << *p; // Prints: 5
    delete p;
}
/*5*/
