//12-02-ComplexAccessSpecifier.cpp
#include <iostream>
#include <cmath>
using namespace std;
class Complex
{
public:
    double re,im;
public:
    double norm() {return sqrt(re*re + im*im);}   
};
void print(const Complex& t)
{
    cout << t.re << " + j" << t.im << endl;
}
int main()
{
    Complex c = {3.7 , 8.3};
    print (c);
    cout << c.norm();
}
/*3.7 + j8.3
9.08735*/

