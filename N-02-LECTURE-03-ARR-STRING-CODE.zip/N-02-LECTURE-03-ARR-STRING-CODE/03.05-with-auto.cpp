//ERROR DOESN'T WORK
// Add_strings_c++.cpp
#include <iostream>
#include <string>
using namespace std;
int main(void) { auto str1 = "HELLO";
    auto str2 = "WORLD";

    auto str = str1 + str2;

    cout << str;
}
/*HELLOWORLD*/