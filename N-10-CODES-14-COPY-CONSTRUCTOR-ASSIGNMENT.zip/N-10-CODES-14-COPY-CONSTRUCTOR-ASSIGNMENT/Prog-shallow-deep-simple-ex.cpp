#include <iostream>
using namespace std;
class A {
public:
    int x;
    int *p;
    A(){
        x = 5;
        p = new int(5);
    }
    //compiler Copy constructor behaviour
    //shallow copy 
    A(const A &obj) {
    x = obj.x; 
    p = new int;
    *p = *(obj.p);
    }
    };
   
int main() {
    A obj1;
    A obj2(obj1); // Calls the default copy constructor

    cout << "before change:" << endl;
    cout << "obj1.x = " << obj1.x << endl;
    cout << "obj1.p = " << *(obj1.p) << endl;
    cout << "obj2.x = " << obj2.x << endl;
    cout << "obj2.p = " << *(obj2.p) << endl;

    obj1.x = 10;
    *(obj1.p) = 10;

    cout << "after change:" << endl;
    cout << "obj1.x = " << obj1.x << endl;
    cout << "obj1.p = " << *(obj1.p) << endl;
    cout << "obj2.x = " << obj2.x << endl;
    cout << "obj2.p = " << *(obj2.p) << endl;
}
