// Program-concat-by-string-09.01.cpp
#include <iostream>
#include <cstring>
using namespace std;
typedef struct _String { char *str; } String;
int main() { String lName, fName, name;
    fName.str = strdup("Partha ");
    lName.str = strdup("Das");
    name.str = (char *) malloc( // Allocation 
    strlen(fName.str)+ 
    strlen(lName.str) +1);
    strcpy(name.str, fName.str);
    strcat(name.str, lName.str);
    cout <<"First Name: "<<fName.str<< endl;
    cout <<"Last Name: "<<lName.str<< endl;
    cout <<"Full Name: " <<name.str<< endl;
}  
