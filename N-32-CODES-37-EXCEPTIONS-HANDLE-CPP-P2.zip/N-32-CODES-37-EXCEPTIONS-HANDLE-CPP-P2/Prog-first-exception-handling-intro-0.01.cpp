#include <iostream>
#include <stdexcept>

int main() {
    try {
        int a, b;
        std::cout << "Enter two ( int )numbers (dividend and divisor): ";
        std::cin >> a >> b;

        if (b == 0) {
            throw std::runtime_error("Division by zero error!");
        }

        int result = a / b;
        std::cout << "Result: " << result << std::endl;
    }
    catch (const std::runtime_error& e) {
        std::cout << "Exception caught: " << e.what() << std::endl;
    }

    std::cout << "Program continues..." << std::endl;
    return 0;
}
