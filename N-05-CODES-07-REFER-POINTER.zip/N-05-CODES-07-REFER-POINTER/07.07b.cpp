// program 07.07b
#include <iostream>
using namespace std;
int& Return_ref (int &x) {
    int t = x;
    t++;
    return (t);
}
int main() { int a = 10, b = Return_ref(a);
    cout << "a = " << a <<" and b = " << b << endl;
    Return_ref(a) = 3; // Changes local t
    cout << "a = " << a;
    }
    /*warning: reference to local variable 't' returned*/
  
  /*
  // This code got from net behaves  
  #include <iostream>
using namespace std;
int Return_ref(int &x) {
    int t = x;
    t++;
    return t;
}

int main() { int a = 10, b = Return_ref(a);
    cout << "a = " << a << " and b = " << b << endl;
    int temp = Return_ref(a);  // Save the returned value to a temporary variable
    temp = 3;  // This assignment won't affect `a` since `Return_ref` no longer returns a reference
    cout << "a = " << a << endl;
}*/
