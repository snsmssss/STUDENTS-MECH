#include <iostream>
#include<memory>
using namespace std;

int main()
{
    //unique_ptr  
    {
        unique_ptr<int> unPtr1 = make_unique<int>(100);
        unique_ptr<int> unPtr2 = move(unPtr1);
        cout << "Unique ptr=" << *unPtr2 << endl;
    }
   
    return 0;
}