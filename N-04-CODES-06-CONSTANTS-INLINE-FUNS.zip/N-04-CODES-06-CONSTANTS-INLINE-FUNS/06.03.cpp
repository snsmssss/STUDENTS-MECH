// program 06.03
#include <iostream>  // Header replaced by CPP
using namespace std;
//#define of SQUARE(x) consumed by CPP

int main() {
    int a = 3, b;
    b = a * a; // Replaced by CPP
    cout << "Square = " << b << endl;
}
/*Square = 9*/