#include <iostream>
using namespace std;
class Base {
public:
    Base(int x) {
        cout << "Base class constructor called with x = " << x << std::endl;
    }
};
class Derived : public Base {
public:
    // Derived class constructor
    Derived(int x, int y) : Base(x) {  // Explicitly calling the Base class constructor
        cout << "Derived class constructor called with y = " << y << std::endl;
    }
};
int main() {
    Derived obj(10, 20);  // Calls both Base and Derived constructors
    return 0;
}
