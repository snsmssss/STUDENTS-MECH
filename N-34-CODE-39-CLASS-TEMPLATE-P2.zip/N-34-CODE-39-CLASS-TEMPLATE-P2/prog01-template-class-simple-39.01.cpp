#include <iostream>
using namespace std;

template <typename T> 
class MyClass
{
private:
    T data;
public:
    MyClass(T d):data(d){}
    T getData(){return data;}
};

int main()
{
    MyClass<int> intObj(100);
    MyClass<double> doubleObj(3.14);

    int i = intObj.getData();
    double d = doubleObj.getData();

    cout << "i = "<< i << "d = " << d <<endl;
    return 0;
}