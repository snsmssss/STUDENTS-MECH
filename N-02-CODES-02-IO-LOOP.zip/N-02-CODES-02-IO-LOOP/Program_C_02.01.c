//Hello World.c
#include <stdio.h>
int main() {
    printf("Hello World i C");
    printf("\n");
    return 0;
}
