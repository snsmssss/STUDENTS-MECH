//  program 06.01
// Contents of <iostream> header replaced bu CPP
// Contents of <cmath> header replaced by CPP
#include <iostream>
#include <cmath>
using namespace std;

// #define of TWO consumed by CPP
// #define of PI consumed by CPP

int main() { int r = 10;
    double peri = 2 * 4.0*atan(1.0) * r; // By CPP
    cout << "Perimeter = " << peri << endl;
}
/*Perimeter = 62.8319*/