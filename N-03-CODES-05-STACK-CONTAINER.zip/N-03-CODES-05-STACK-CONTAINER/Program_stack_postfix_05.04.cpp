#include <iostream>
#include <stack> // Library codes
using namespace std;



/*Evaluation 3*/

