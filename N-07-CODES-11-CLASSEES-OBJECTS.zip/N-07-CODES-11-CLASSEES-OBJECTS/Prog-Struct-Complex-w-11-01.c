#include <stdio.h>

// Define a structure for complex numbers
typedef struct Complex {
    double re, im; // Real and imaginary parts
} Complex;

int main() {
    // Initialize a complex number
    Complex c = {3.7, 8.3}; // Initialize using curly braces

    // Output the real and imaginary parts of the complex number
    printf("%lf %lf", c.re, c.im); // Access using dot operator

    return 0;
}
