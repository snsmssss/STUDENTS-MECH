//13-11-StackDestructorUser.cpp
#include <iostream>
using namespace std;
class Stack{private: char *data_; int top_;//Dynamic
public:Stack():data_(new char[10]),top_(-1)
    {cout << "Stack() called\n";}//Constructor
    void de_init(){delete [] data_;} 
void push(char x){data_[++top_] = x;}
int empty(){return(top_ == -1);}
void pop(){--top_;}
char top(){return data_[top_];}};

int main() { char str[10] = "ABCDE";
    Stack s; // Init by Stack::Stack(): call 
    for(int i=0; i < 5; ++i) s.push(str[i]);
    while (!s.empty()) {cout << s.top(); s.pop();}
    s.de_init();
}    
//.\13-11-StackDestructorUser.exe
//Stack() called
//EDCBA