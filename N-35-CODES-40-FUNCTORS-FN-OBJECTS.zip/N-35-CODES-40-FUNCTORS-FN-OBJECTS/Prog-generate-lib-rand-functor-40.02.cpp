#include <iostream>
#include <algorithm>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <algorithm>
using namespace std;

void print(int value) {
    cout << value << " ";
}

int main()
{
    vector<int> V(100);
     // Seed rand() for better randomness
    srand(time(0));
    
    generate(V.begin(), V.end(),rand);
#if 0
    for (int i = 0; i < 11; ++i)
    {
        cout << V[i] << " ";
    }
    cout << endl; 
#endif
// Using std::for_each to print each element
    for_each(V.begin(), V.end(), print);

    return 0;
}