
#include <iostream>
#include <string>
using namespace std;
template<class T> void Swap(T& one, T& other)
{ T temp; temp = one; one = other; other = temp; 
} 
int main()
{ int i = 10, j = 20;

cout << "i = " << i << ", j = "<< j << endl;
Swap(i, j);
cout << "i = " << i << ", j = "<< j << endl;

string sl("abc"), s2("def"); 


cout << "sl = "<< s1 <<", s2 = "<< s2 << endl; 
Swap(sl,s2);
cout << "sl = "<< s1 <<", s2 = "<< s2 << endl; 

} 

