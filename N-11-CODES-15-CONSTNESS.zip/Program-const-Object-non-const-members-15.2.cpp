//15-2.cpp
#include <iostream>
using namespace std;
class MyClass { int myPriMember_;
 public:
  int myPubMember_;
     MyClass(int mPri, int mPub) : myPriMember_(mPri), myPubMember_(mPub) { }
     int getMember() const{ return myPriMember_; }
     void setMember(int i) { myPriMember_ = i; }
     void print() { cout << myPriMember_ << ", " << myPubMember_ <<endl; }
};
int main() {  
    const MyClass myConstObj(5, 6);      // constant object
  cout << myConstObj.getMember() << endl; //Error 1
     //myConstObj.setMember(7);              //Error 2
    //myConstObj.myPubMember_ = 8;          //Error 3
   //myConstObj.print();                   //Error 4
} 
/5
