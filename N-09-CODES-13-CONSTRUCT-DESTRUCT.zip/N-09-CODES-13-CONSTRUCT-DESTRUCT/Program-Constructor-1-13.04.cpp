//13-04-StackPrivateDataAccess.cpp
#include <iostream>
using namespace std;
class Stack{private: char data_[10]; int top_;//Automatic
public:Stack(); // Constructor
void push(char x){data_[++top_] = x;}
int empty(){return(top_ == -1);}
void pop(){--top_;}
char top(){return data_[top_];}
};
Stack::Stack(): //Initialization List
    top_(-1) { cout << "Stack::Stack():" << endl;}
int main() { char str[10] = "ABCDE";
    Stack s; // Init by Stack::Stack(): call 
    for(int i=0; i < 5; ++i) s.push(str[i]);
    while (!s.empty()) {cout << s.top(); s.pop();}
}    
/*Stack::Stack():
EDCBA*/