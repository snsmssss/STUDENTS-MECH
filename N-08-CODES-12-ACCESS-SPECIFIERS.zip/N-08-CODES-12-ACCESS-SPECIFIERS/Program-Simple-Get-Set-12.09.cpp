//Program-Simple-Get-Set-12.09.cpp
#include <iostream>
#include <cstdlib>
using namespace std;
class item
{
    int number;//private default
    float cost;//private default
   public:
    void getdata(int a, float b)
    {
        this->number = a;
        cost = b;
    }
    void putdata(void)
    {
        cout << "number :" << number << endl;
        cout << "cost :" << cost << endl;
    }
};
int main()
   {
    item x;
    x.getdata(99, 2017.0);
    x.putdata();
    return 0;
   }