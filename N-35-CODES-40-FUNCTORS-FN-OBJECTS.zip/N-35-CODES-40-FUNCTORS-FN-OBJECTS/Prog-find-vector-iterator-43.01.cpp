//Prog-find-vector-iterator-43.01.cpp 
#include <iostream>
#include <vector>
using namespace std;

// Template function to find the first element that equals a value
template<class In, class T>
In find(In first, In last, const T& val) {
    while (first != last && *first != val) {
        ++first;
    }
    return first;
}

// Function that uses the custom find function to search for an integer in a vector
void f(vector<int>& v, int x) {
    vector<int>::iterator p = find(v.begin(), v.end(), x);
    if (p != v.end()) {
        cout << "Found " << x << " at position " << distance(v.begin(), p) << endl;
    } else {
        cout << x << " not found in the vector." << endl;
    }
}

int main() {
    vector<int> numbers = {10, 20, 30, 30, 50};  // Sample vector of integers
    
    int x;
    cout << "Enter a number to find in the vector: ";
    cin >> x;
    
    f(numbers, x);  // Search for the number in the vector

    return 0;
}
