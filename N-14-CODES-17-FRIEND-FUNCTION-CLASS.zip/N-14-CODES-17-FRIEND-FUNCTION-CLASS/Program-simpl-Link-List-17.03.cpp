//Program-simpl-Link-List-17.03.cpp
#include <iostream>
using namespace std;

class Node
{
private:
    int Value; 
    Node* Next;
public:
    void printList(Node* );
    void setV(int x){Value=x;}
    void setN(Node* y){Next = y;}
    friend printList(Node* a);
};
void printList(Node* a)
{
while(a!=NULL)
{
    cout<<a->Value<<endl;
    a = a->Next;
}
}
int main()
{
    Node* head = new Node();
    Node* second = new Node();
    Node* third = new Node();
    
    head->Value = setV(1);
    head->Next = setN(second);
 /* //second->Value = 2;
    second.get_data(2);
    second->Next = third;
    //third -> Value = 3;
    third.get_data(3);
    third-> Next = NULL;*/
    
    printList(head);
    return 0;
}

