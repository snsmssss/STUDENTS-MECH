// This code got from net behaves
// Program_risky_ret_by_ref.07.07.cpp
#include <iostream>
using namespace std;
int Return_ref(int &x) {
    int t = x;
    t++;
    return t;
}
int main() { int a = 10, b = Return_ref(a);
    cout << "a = " << a << " and b = " << b << endl;
    int temp = Return_ref(a);
//Saved the returned value to a temporary variable
    temp = 3;
//This assignment won't affect `a`since `Return_ref`no longer returns a reference
    cout << "a = " << a  << endl;
}
