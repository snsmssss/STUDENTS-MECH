//Pr-vecsum-STL-functor-with-st-40.15.cpp
#include <iostream>
#include <algorithm>
#include <vector>
//#include <functional>
using namespace std;
class adder: public unary_function<double, void> 
{    
public:
double sum; // Local state
adder(): sum (0) { }
void operator() (double x) { sum += x; }
};
int main()
{
vector<double> V={10,20,30,40};
adder result = for_each (V.begin(), V.end(), adder());
cout << "The sum is " << result.sum << endl;
return 0;
}
