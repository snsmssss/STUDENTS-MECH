// Add_strings_c++.cpp
#include <iostream>

#include <string>
using namespace std;
int main(void) { string str1 = "HELLO";
    string str2 = "WORLD";

    string str = str1 + str2;

    cout << str;
}
/*HELLOWORLD*/