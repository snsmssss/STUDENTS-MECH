//Memory Leak happens when you dynamically
//allocate memory in heap area but you forgot to 
//deallocate itword to allocate - if you don't use 'delete'
//keyword to deallocate to free the memory resource

// U use 'new' key 
//run this code on Linux with valgrind
//to run this code you need valgrind
//g++ -g ex2_macro.cpp -o a.out
//valgrind --leak_check=yes ./a.out

#include <iostream>
using namespace std;

int main()
{
    //space for an int value is allocated in heap with 'new' 
    int *intPtr = new int[10];
    *intPtr = 7;
    cout <<"intPtr = "<<*intPtr<<endl;
    //done with what intPtr points to
    //forgot to free it with 'delete'
    return 0;
}