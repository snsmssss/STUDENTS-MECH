//Program-enum-09.05
#include <iostream> 
using namespace std; 
enum week {Mon,Tue,Wed,Thu,Fri,Sat,Sun}; 
int main() 
{ 
week first_day,week_end; 
int x = -1;

first_day = Mon;
week_end  = Fri;
x = first_day + week_end;
 /*cout << "Day: " << first_day+1<<endl;
 cout << "Week-end: " << week_end+1<<endl;*/ 
 cout << "x: " << x << endl;
 return 0; 
}
