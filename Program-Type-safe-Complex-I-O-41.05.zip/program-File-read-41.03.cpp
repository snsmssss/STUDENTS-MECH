#include <iostream>
#include <fstream>
#include <string>
using namespace std;
int main () {ifstream myfile("example.txt");//input
    string line;
    if(myfile.is_open()){   //open
        while(getline(myfile,line)) //unformatted read
        cout << line << '\n';
        myfile.close();  // close
        }
        else cout << "unable to open file";
    }
   
    