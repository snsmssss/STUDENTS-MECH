//  Program_constant_pointer_06.05
#include <iostream>
#include <cmath>
using namespace std;

int main(void)
{
    int a[] = {10,11};
    int* const ptr = a;

    *ptr = 11;

    cout << "value at ptr is  : "<< *ptr <<endl;
    cout << "Address pointed by ptr is  : "<< ptr << endl;
    
    ptr++;
    
    cout << "Address pointed by ptr is  : "<< ptr << endl;
    return 0;
}