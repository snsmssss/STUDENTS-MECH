#include<bits/stdc++.h>
using namespace std;
class GFG {
public:
    void call_Function()//function that call print
    {
        print();
    }
    virtual void print()//using "virtual"fordisplay function 
{
cout <<"Printing the Base class Content"<< endl;
}
};
class GFG2 : public GFG//GFG2 inherit a publicly
{
public:
    void print() // GFG2's display
    {
    cout<<"Printing the Derived class Content"<<endl;
    }
};
int main()
{
    GFG g; // Creating GFG's object
    g.call_Function();//Calling call_Funct.
    GFG2 g2; //creating GFG2 object
    g2.call_Function();//calling call_Funct.
     //for GFG2 object
return 0;
}

