#include<iostream>
using namespace std; 
class B { public:
      void f() { } 
}; 
class D : public B{ public:
    virtual void f() { }
};
int main(){
    B b;
    D d;
    B *p;

    p = &b; p-> f(); //B::f()
    p = &d; p-> f(); //D::f()
}
