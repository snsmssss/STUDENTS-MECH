//Prog-direct-fun-ptr-40.04.cpp 
#include <stdio.h>

int (*pt2Function) (int, char, char);
int DoIt (int a, char b, char c);

int main() {
    pt2Function = DoIt; // &DoIt

    int result = (*pt2Function)(12, 'a', 'b');

    printf("%d", result);
    return 0;
}

int DoIt (int a, char b, char c) {
    printf("DoIt\n");
    return a + b + c;
}

//DoIt
//207